const router = require('express').Router();

const answerController = require("../Controller/answercntrlr");

router.post('/answers',answerController.addAnswer);

router.post('/showAnswers' , answerController.displayAnswers);

module.exports = router;