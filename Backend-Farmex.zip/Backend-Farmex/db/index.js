const mongoose = require('mongoose');

require("dotenv").config();

mongoose.connect(`mongodb+srv://semmo1207:7LkOMHfeRTsxVB6L@sample.z5g7n.mongodb.net/?retryWrites=true&w=majority&appName=Sample/farm_db`,{ useNewUrlParser: true, useUnifiedTopology: true }).catch((error)=>{console.log(error)});

mongoose.connection.once('open', () => {
    console.log('atlas started')
})
const db = mongoose.connection;

db.on('error',console.error.bind(console,'MongoDB connection error'));

module.exports = db;
