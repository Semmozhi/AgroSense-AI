import React from 'react';

function Feedback() {
  return (
    <div>
      <h2 className="text-9xl bg-orange-600">Feedback Us</h2>
      <p>If you have any questions or inquiries, please feel free to get in touch with us.</p>
    </div>
  );
}

export default Feedback;
